package com.example.kiemtralan1

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class KiemTraLan1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtMon1 = findViewById<EditText>(R.id.edtMon1)
                val edtMon2 = findViewById<EditText>(R.id.edtMon2)
                val edtMon3 = findViewById<EditText>(R.id.edtMon3)
                val btnTinh = findViewById<Button>(R.id.btnTinh)
                val btnLamLai = findViewById<Button>(R.id.btnLamLai)
                val tvKetQua = findViewById<TextView>(R.id.tvKetQua)

                btnTinh.setOnClickListener {
            val s1 = edtMon1.text.toString()
            val s2 = edtMon2.text.toString()
            val s3 = edtMon3.text.toString()

            // Kiểm tra rỗng
            if (s1.isEmpty() || s2.isEmpty() || s3.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đủ 3 điểm!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val d1 = s1.toDouble()
                val d2 = s2.toDouble()
                val d3 = s3.toDouble()

                // Kiểm tra phạm vi
                if (d1 !in 0.0..10.0 || d2 !in 0.0..10.0 || d3 !in 0.0..10.0) {
                    Toast.makeText(this, "Điểm phải trong khoảng 0 - 10!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val tb = ((d1 + d2 + d3) / 3)
                val tbLamTron = String.format("%.2f", tb)

                val xepLoai = when {
                    tb >= 8 -> "Giỏi"
                    tb >= 6.5 -> "Khá"
                    tb >= 5 -> "Trung bình"
                    else -> "Yếu"
                }

                tvKetQua.text = "Điểm TB: $tbLamTron\nXếp loại: $xepLoai"

            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Điểm phải là số hợp lệ!", Toast.LENGTH_SHORT).show()
            }
        }

        btnLamLai.setOnClickListener {
            edtMon1.setText("")
            edtMon2.setText("")
            edtMon3.setText("")
            tvKetQua.text = ""
            edtMon1.requestFocus()
        }
    }
}
